function [status, result] = runSchedulerCommand(cmd)
%RUNSCHEDULERCOMMAND Make a system call to the scheduler, sanitizing any
% return signals.
%
% Some scheduler utility commands on unix return exit codes > 127, which
% MATLAB interprets as a fatal signal. This is not the case here, so wrap
% the system call to the scheduler on UNIX within a shell script to
% sanitize any exit codes in this range.

% Copyright 2019 The MathWorks, Inc.

persistent wrapper

if isunix
    if isempty(wrapper)
        wrapper = fullfile( toolboxdir('parallel'), ...
            'bin', 'util', 'shellWrapper.sh' );
    end
    cmd = convertStringsToChars(cmd);
    cmd = [wrapper, ' ', cmd];
end

[status, result] = system(cmd);
